package com.cardoso_izaac.SimpleAuthentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleAuthenticationApplicationTests {

	@Test
	void contextLoads() {
	}

}
